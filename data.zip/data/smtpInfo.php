<?php
$smtpInfo = [
    'Username' => 'recuperacao_senha@grupofirstrh.com.br',
    'Password' => 'e*[#VZEGQ!u,'
];
